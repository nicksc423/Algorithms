//
//  headNode.swift
//  DataStructures
//
//  Created by Nicholas Solow-Collins on 2/29/16.
//  Copyright © 2016 Nicholas Solow-Collins. All rights reserved.
//

import Foundation
class HeadNode<T> {
    var next: T?
}
